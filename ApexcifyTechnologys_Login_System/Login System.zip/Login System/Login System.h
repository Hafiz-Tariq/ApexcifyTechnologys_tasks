#pragma once

bool checkUser(string userName);

void registerPassword(string userName, string password);

void registerUser(string userName, string password);
